This is our code for the software portion of the maze solving code.
By: Mohammad Durrani, Nitin Krishna, Pranav Shah, Karthik Taranath

To run, in one terminal run:
ros2 launch maze_simulation maze_2_launch.py

In another terminal, run:
ros2 run maze_simulation final_maze_solver